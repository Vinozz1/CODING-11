import { people, ages } from './people.js';

console.log(people);
console.log(ages);

import { circle, square, squarePerimater, rectangle, triangle } from './area.js';

console.log(circle(7));
console.log(square(4));
console.log(squarePerimater(4));
console.log(rectangle(4, 8));
console.log(triangle(4, 10));

