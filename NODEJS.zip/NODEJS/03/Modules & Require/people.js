const people = ['John',' Jane', 'Doe'];
const ages = [30, 25, 40];

export {people, ages};