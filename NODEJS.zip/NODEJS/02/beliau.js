const beliau = [
    'tinggi',
    'long hair',
    'kinda cute'
];

const measurement = [ 168, 54];

module.exports = {beliau, measurement};