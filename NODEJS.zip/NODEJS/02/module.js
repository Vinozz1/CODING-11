const {people, ages, addNumber} = require('./people')

// console.log({people, ages, addNumber});
console.log(people);
console.log(addNumber(10, 30));

const {beliau, measurement} = require('./people')

console.log(beliau);