const people = [
    'Amdi',
    'Budi',
    'Cindy',
    'Dodi'
];

const ages = [20, 30, 40, 50];

const addNumber = (a, b) => {
    return a + b;
}

// console.log(people);
// module.export = people;
module.exports = {people, ages, addNumber};