let name = "albob";

console.log(`Hello, ${name}`);

if (name) {
    setInterval(() => {
        console.log(`Spidolnya jangan jatuh , ${name}`);
    }, 1000);
}